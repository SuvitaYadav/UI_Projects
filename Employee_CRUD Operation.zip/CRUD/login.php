<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS v5.2.1 -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
      crossorigin="anonymous"
    />
  </head>

  <body>
    <header>
      <!-- place navbar here -->
    </header>
    <main>

    <h2 style="color: black" class="text-center mt-5">
    Login!!
    </h2>
        <div style="background-color: rgb(227, 222, 152); "
        class="container p-5 col-5 mp-2 mt-5 image-fluid rounded;">

          <form action="" method="post"> 
          <div class="form-floating mb-3">
            <input
              type="text"
              class="form-control"
              name="uname"
              id=""
              placeholder=""
              required
            />
            <label for="formId1">Username</label>
          </div>

          <div class="form-floating mb-3">
            <input
              type="password"
              class="form-control"
              name="pass"
              id=""
              placeholder=""
            />
            <label for="formId1">Password</label>
          </div>

          <div class="text-center pt-4 pb-3">
            <button type="submit" class="btn btn-dark">Submit</button>
          </div>
        </form>
      </div>
    </main>
    <footer>
      <!-- place footer here -->
    </footer>
    <!-- Bootstrap JavaScript Libraries -->
    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
      integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
      crossorigin="anonymous"
    ></script>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
      integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
      crossorigin="anonymous"
    ></script>
  </body>
</html>

<?php

  include 'DB.php';

  session_start();

  if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $uname = $_POST["uname"];
    $pass = $_POST["pass"];

    $sql= $conn->prepare("select id,password from crud where username=?");
    $sql->bind_param("s", $uname);

    $sql->execute();

    $sql->store_result();

    $sql->bind_result($id, $password);

    if($sql->fetch() && password_verify($pass, $password)) {
      $_SESSION["username"] = $uname;
      header("Location:home.php");
    } else {
      echo "Please enter valid credentials";
    }

  }

?>