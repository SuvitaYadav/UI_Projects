<?php
    include 'DB.php';

    if(isset($_GET['id'])){
      $id= $_GET["id"];
      $sql=$conn->prepare("delete from crud_op where id=?");
      $sql->bind_param("i",$id);
      if($sql->execute()){
        header("Location:insert.php");                                                                          
      }
    }
?>