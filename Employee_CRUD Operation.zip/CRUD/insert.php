<?php

include 'DB.php';
session_start();

// Insert logic
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST["name"];
    $role = $_POST["role"];
    $sal = $_POST["sal"];
    $jdate = $_POST["jdate"];
    $ctc = $_POST["ctc"];

    $sql = $conn->prepare("INSERT INTO crud_op(name, role, salary, joining_date, ctc) VALUES (?, ?, ?, ?, ?)");
    $sql->bind_param("ssdsd", $name, $role, $sal, $jdate, $ctc);

    if ($sql->execute()) {
        echo "<script>alert('Employee added successfully'); window.location.href='insert.php';</script>";
        exit;
    } else {
        echo "<script>alert('Failed to add employee: " . $conn->error . "');</script>";
    }
}

// Fetch employee records
$result = $conn->query("SELECT * FROM crud_op");
?>

<!doctype html>
<html lang="en">
  <head>
    <title>Employee Management</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!-- Bootstrap CSS -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
  </head>
  <body>
    <main class="container mt-4">

      <!-- Insert Form -->
      <div class="bg-light p-4 rounded shadow-sm col-lg-8 mx-auto">
        <h2 class="text-center text-primary mb-4">Add New Employee</h2>
        <form action="" method="POST">
          <div class="form-floating mb-3">
            <input type="text" class="form-control" name="name" id="name" required />
            <label for="name">Name</label>
          </div>

          <div class="form-floating mb-3">
            <input type="text" class="form-control" name="role" id="role" required />
            <label for="role">Role</label>
          </div>

          <div class="form-floating mb-3">
            <input type="number" class="form-control" name="sal" id="sal" required />
            <label for="sal">Salary</label>
          </div>

          <div class="form-floating mb-3">
            <input type="date" class="form-control" name="jdate" id="jdate" required />
            <label for="jdate">Joining Date</label>
          </div>

          <div class="form-floating mb-3">
            <input type="number" class="form-control" name="ctc" id="ctc" />
            <label for="ctc">CTC</label>
          </div>

          <div class="text-center">
            <button type="submit" class="btn btn-success px-4">Submit</button>
          </div>
        </form>
      </div>

      <!-- Employee Table -->
      <div class="mt-5 col-lg-10 mx-auto">
        <h2 class="text-center text-dark mb-3">Employee Records</h2>
        <div class="table-responsive">
          <table class="table table-bordered table-hover text-center align-middle">
            <thead class="table-dark">
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Role</th>
                <th>Salary</th>
                <th>Joining Date</th>
                <th>CTC</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($result && $result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                  <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['name'] ?></td>
                    <td><?= $row['role'] ?></td>
                    <td><?= $row['salary'] ?></td>
                    <td><?= $row['joining_date'] ?></td>
                    <td><?= $row['ctc'] ?></td>
                    <td>
                      <a href="update.php?id=<?= $row['id'] ?>" class="btn btn-primary btn-sm me-2">Edit</a>
                      <a href="delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Are you sure?');" class="btn btn-danger btn-sm">Delete</a>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="7">No records found.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
            <div class="mb-5 text-center">
      <a style="margin-left: 20px"; href="export.php"><button type="submit" class="btn btn-primary">Download Excel_file</button></a>
      <a style="margin-left: 20px"; href="emp-pdf.php"><button type="submit" name="submit" class="btn btn-primary">Download PDF_File</button></a> 
      <a  class="mx-2" href="home.php">Home</a>
    </div>
    </main>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
