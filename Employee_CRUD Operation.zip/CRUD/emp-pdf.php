<?php
  require('vendor/autoload.php');

  $conn = mysqli_connect('localhost','root','','e1_php');

  $result = mysqli_query($conn,"select * from crud_op");

  if(mysqli_num_rows($result) > 0){
    $html = '<style></style><table border="1"; class="table">';
    $html.='<tr><td>ID</td><td>Name</td><td>Role</td><td>Salary</td><td>Joining Date</td><td>CTC</td></tr>';

    while($row = mysqli_fetch_array($result)){
      $html.= '<tr><td>'.$row['id'].'</td><td>'.$row['name'].'</td><td>'.$row['role'].'</td><td>'.$row['salary'].'</td><td>'.$row['joining_date'].'</td><td>'.$row['ctc'].'</td></tr>';
    }
    $html.='</table>';
  }
    else{
      $html.="Data not found";
    }
  
    // $html = '<h1 style="color: green">Example</h1>';
    // $html.= "Hello <em>Suvita</em>";
    // $html.= '<img src="MG_1.png">';

    $mpdf = new \Mpdf\Mpdf();
    $mpdf->WriteHTML($html);
    
    $file='Employee_Details/'.time().'.pdf';
    $mpdf->output($file,'I');
?>