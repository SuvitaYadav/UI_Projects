<?php

  $servername = 'localhost';
  $username = 'root';
  $password = "";
  $dbname = "e1_php";

  $conn = new mysqli($servername, $username, $password, $dbname);
  if (!$conn) {
      die("Database not connected");
  }

?>