<?php

    include 'DB.php';

    $id=isset($_GET['id'])?($_GET['id']):null;

  if($id){
    $sql= $conn->prepare("select id,name,role,salary,joining_date,ctc from crud_op where id=?");
    $sql->bind_param("i",$id);
    $sql->execute();
    $user=$sql->get_result()->fetch_assoc();
    if(!$user){
      echo "No recoder found in database";
    }

    if($_SERVER['REQUEST_METHOD']=="POST"){
      $id = $_POST["id"];
      $name = $_POST["name"];
      $role = $_POST["role"];
      $sal = $_POST["sal"];
      $jdate = $_POST["jdate"];
      $ctc = $_POST["ctc"];
      
      $sql_update = $conn-> prepare("update crud_op set name=?,role=?,salary =?,joining_date=?,ctc=? where id =?");
      $sql_update -> bind_param("ssdsdi", $name, $role, $sal, $jdate, $ctc, $id);

      if($sql_update->execute()){
        header("Location:insert.php");
      }
    }

  }
?>

<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS v5.2.1 -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
      crossorigin="anonymous"
    />
  </head>

  <body>
    <header>
      <!-- place navbar here -->
    </header>
    <main>
      <h2 class="text-center text-dark mt-5">Edit</h2>
      <div style="background-color: rgb(135, 147, 183)" class="container text-center image-fluid rounded col-7 p-5 mt-4 image">
        <form action="" method="post">
          
             <div class=" form-floating mb-3">
              <input
                type="hidden"
                class="form-control"
                name="id"
                id=""
                placeholder=""
                value="<?=$user["id"]?>"
              />
             </div>
             
             <div class="form-floating mb-3">
            <input
              type="text"
              class="form-control"
              name="name"
              id="formId1"
              placeholder=""
              value="<?=$user["name"]?>"
            />
            <label for="formId1">Name</label>
          </div>
          <div class=" form-floating mb-3">
              <input
                type="text"
                class="form-control"
                name="role"
                id=""
                placeholder=""
                value="<?=$user["role"]?>"
              />
              <label for="" class="form-label">Role</label>
             </div>
             <div class=" form-floating mb-3">
              <input
                type="number"
                class="form-control"
                name="sal"
                id=""
                placeholder=""
                value="<?=$user["salary"]?>"
              />
              <label for="" class="form-label">Salary</label>
             </div>
             <div class=" form-floating mb-3">
              
              <input
                type="date"
                class="form-control"
                name="jdate"
                id=""
                placeholder=""
                value="<?=$user["joining_date"]?>"
              />
              <label for="" class="form-label">Joining Date</label>
             </div>
             <div class=" form-floating mb-3">
              <input
                type="number"
                class="form-control"
                name="ctc"
                id=""
                placeholder=""
                value="<?=$user["ctc"]?>"
              />
              <label for="" class="form-label">CTC</label>
             </div>
             <div class="text-center pt-3">
             <button
              type="submit"
              class="btn btn-primary me-5"
             >
              Submit
             </button>
             <a  class="" href="insert.php">Back</a>
             </div>
        </form>
      </div>
    </main>
    <footer>
      <!-- place footer here -->
    </footer>
    <!-- Bootstrap JavaScript Libraries -->
    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
      integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
      crossorigin="anonymous"
    ></script>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
      integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
