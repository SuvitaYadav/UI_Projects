<?php
  include("DB.php");
  session_start();
  if(!isset($_SESSION["username"])){
    header("Location:login.php");
    exit;
  }
?>

<!doctype html>
<html lang="en">
  <head>
    <title>Welcome Home</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />

    <style>
      body {
        background-image: url('https://www.shutterstock.com/image-photo/employee-confidentiality-software-security-searching-260nw-2088710632.jpg');
        background-size: cover;
        background-position: center;
        height: 100vh;
        margin: 0;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      }

      .welcome-box {
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border-radius: 20px;
        padding: 40px;
        color: white;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
      }

      .btn-glow {
        background-color: #007bff;
        border: none;
        padding: 12px 24px;
        font-size: 18px;
        transition: all 0.3s ease;
        text-decoration: none;
        color: white;
        border-radius: 8px;
      }

      .btn-glow:hover {
        background-color: #0056b3;
        transform: scale(1.05);
        box-shadow: 0 0 15px rgba(0, 123, 255, 0.6);
      }

      a.btn-glow {
        text-decoration: none;
      }
    </style>
  </head>

  <body>
    <main class="d-flex justify-content-center align-items-center" style="height: 100vh;">
      <div class="welcome-box text-center col-md-6 col-lg-5">
        <h1>Welcome, <strong><?= $_SESSION["username"] ?></strong></h1>
        <p class="mt-3 fs-5">Ready to manage employee details?</p>

        <div class="mt-4">
          <a href="insert.php" class="btn-glow">➕ Add Employee Details</a>
        </div>

        <div class="mt-4">
          <a href="logout.php" class="text-light text-decoration-underline">Logout</a>
        </div>
      </div>
    </main>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
