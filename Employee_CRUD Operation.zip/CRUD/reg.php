<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS v5.2.1 -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
      crossorigin="anonymous"
    />
  </head>

  <body>
    <header>
      <!-- place navbar here -->
    </header>
    <main>
      
    <h2 style="color: black" class="text-center mt-5">
    Register With Us!!
    </h2>
        <div style="background-color: rgb(188, 188, 133) ;" class="container col-9  pt-5">
          <form action="" method="post"> 
          <div class="form-floating mb-3">
            <input
              type="text"
              class="form-control"
              name="name"
              id=""
              placeholder=""
              required
            />
            <label for="formId1">Name</label>
          </div>
          
          <div class="form-floating mb-3">
            <input
              type="text"
              class="form-control"
              name="phone"
              id=""
              placeholder=""
              required
            />
            <label for="formId1">Phone</label>
          </div>

          <div class="form-floating mb-3">
            <input
              type="email"
              class="form-control"
              name="email"
              id=""
              placeholder=""
              required
            />
            <label for="formId1">Email</label>
          </div>

          <div class="form-floating mb-3">
            <input
              type="text"
              class="form-control"
              name="uname"
              id=""
              placeholder=""
              required
            />
            <label for="formId1">Username</label>
          </div>

          <div class="form-floating mb-3">
            <input
              type="password"
              class="form-control"
              name="pass"
              id=""
              placeholder=""
            />
            <label for="formId1">Password</label>
          </div>

          <div class="text-center pt-4 pb-3">
            <button type="submit" class="btn btn-dark">Submit</button>
          </div>
        </form>
      </div>
      <div class="container text-center mt-4 col-4">
        <h4>Already have an account please login <a href="login.php">Login</a></h4>
        </div>
    </main>
    <footer>
      <!-- place footer here -->
    </footer>
    <!-- Bootstrap JavaScript Libraries -->
    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
      integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
      crossorigin="anonymous"
    ></script>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
      integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
      crossorigin="anonymous"
    ></script>
  </body>
</html>

<?php

  include 'DB.php';

  if($_SERVER['REQUEST_METHOD'] == "POST"){
    $name = $_POST["name"];
    $phone = $_POST["phone"];
    $email = $_POST["email"];
    $uname = $_POST["uname"];
    $pass = password_hash($_POST["pass"], PASSWORD_BCRYPT);

    $sql = $conn->prepare("insert into crud(name,phone,email,username,password) values(?,?,?,?,?)");
    $sql->bind_param("sssss", $name, $phone, $email, $uname, $pass);

    if($sql->execute()){
      header("Location:login.php");
    }
    else{
      header("Location:reg.php");
    }

  }
?>