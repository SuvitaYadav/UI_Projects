<?php

  header("Content-Type: application/vnd.ms-excel");
  header("Content-Disposition: attachment; Filename = Employee.xls");

  require 'insert.php';

?>