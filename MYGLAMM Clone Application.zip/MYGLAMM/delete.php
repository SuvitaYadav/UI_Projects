<?php
    include 'DB.php';

    if(isset($_GET['Id'])){
      $id= $_GET["Id"];
      $sql=$conn->prepare("delete from glammin where Id=?");
      $sql->bind_param("i",$id);
      if($sql->execute()){
        header("Location:insert.php");                                                                          
      }
    }
?>