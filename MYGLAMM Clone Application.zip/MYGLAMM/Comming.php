<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS v5.2.1 -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
      crossorigin="anonymous"
    />
  </head>

  <body>
    <header>
      <!-- place navbar here -->
      <nav class="navbar navbar-expand-sm navbar-light bg-light">
        <div class="container">
          <img
            src="https://files.myglamm.com/site-images/original/MG_1.png"
            class="img-fluid ps-5 pe-5"
            alt=""
            height="300px"
            width="300px"
          />

          <div class="collapse navbar-collapse" id="collapsibleNavId">
            <ul class="navbar-nav me-auto mt-2 mt-lg-0">
              <li class="nav-item">
                <a class="nav-link" href="Home.php" aria-current="page"
                  >Home <span class="visually-hidden">(current)</span></a
                >
              </li>
              <li class="nav-item">
                <a class="nav-link" href="show.php"
                  >ShowProduct<span class="visually-hidden">(current)</span></a
                >
              </li>
              <li class="nav-item">
                <a class="nav-link" href="About.php">About Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Contact.php">Contact Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Ty.php">Thank You!</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="Comming.php">Comming Soon</a>
              </li>
            </ul>
            <form class="d-flex my-2 my-lg-0" action="reg.php">
              <button class="btn btn-danger my-2 my-sm-0 me-2" type="submit">
                Register
              </button>
            </form>
            <form class="d-flex my-2 my-lg-0" action="login.php">
              <button class="btn btn-danger my-2 my-sm-0" type="submit">
                Login
              </button>
            </form>
          </div>
        </div>
      </nav>
    </header>

    <main>
      <div class="progress mt-5">
        <div
          class="progress-bar progress-bar-striped progress-bar-animated bg-primary"
          role="progressbar"
          style="width: 50%"
          aria-valuenow="50"
          aria-valuemin="0"
          aria-valuemax="100"
        >
          Completed 50%
        </div>
      </div>

      <div
        class="alert alert-primary alert-dismissible fade show mt-5"
        role="alert"
      >
        <button
          type="button"
          class="btn-close"
          data-bs-dismiss="alert"
          aria-label="Close"
        ></button>

        <strong>Comming Soon</strong> Website 50% Completed
      </div>

      <div class="d-flex justify-content-center align-items-center mt-5">
        <div
          class="spinner-border text-primary spinner-border-sm"
          role="status"
        >
          <span class="visually-hidden">Loading...</span>
        </div>
      </div>

      <!--Pagination-->
      <div class="d-flex justify-content-center mt-5">
        <nav aria-label="Page navigation">
          <ul class="pagination">
            <li class="page-item disabled">
              <a class="page-link" href="#" aria-label="Previous">
                <span aria-hidden="true">&laquo;</span>
              </a>
            </li>
            <li class="page-item" aria-current="page">
              <a class="page-link" href="Home.php">1</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="showe.php">2</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="About.php">3</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="Contact.php">4</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="Ty.php">5</a>
            </li>
            <li class="page-item active">
              <a class="page-link" href="Comming.php">6</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="reg.php">7</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="#" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </main>
    <footer class="text-center bg-dark text-white py-3">
      <!-- place footer here -->
      <h4>&copy; All Rights Are Reserved</h4>
    </footer>
    <!-- Bootstrap JavaScript Libraries -->
    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
      integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
      crossorigin="anonymous"
    ></script>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
      integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
