<?php
  include 'DB.php';
  $id = isset($_GET['Id']) ? ($_GET['Id']) :null;

  if($id){
    $sql = $conn->prepare("select Id,Product,Title,Qty,Amount from glammin where Id=?");
    $sql->bind_param("i", $id);
    $sql->execute();
    $user = $sql->get_result()->fetch_assoc();
    if(!$user){
      echo "No record found in database";
    }

    if($_SERVER['REQUEST_METHOD'] == "POST"){
      $id = $_POST["id"];
      $product = $_POST["product"];
      $title = $_POST["title"];
      $qty = $_POST["qty"];
      $amount = $_POST["amount"];
  
      $sql = $conn->prepare("update glammin set Product=?,Title=?,Qty=?,Amount=? where Id=?");
      $sql->bind_param("ssidi", $product, $title, $qty, $amount,$id);
      
      if($sql->execute()){
        header("Location:insert.php");
      }
    }
  }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS v5.2.1 -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
      crossorigin="anonymous"
    />
  </head>

  <body>
    <header>
      <!-- place navbar here -->
      <nav class="navbar navbar-expand-sm navbar-light bg-light">
        <div class="container">
          <img
            src="https://files.myglamm.com/site-images/original/MG_1.png"
            class="img-fluid ps-5 pe-5"
            alt=""
            height="300px"
            width="300px"
          />

          <div class="collapse navbar-collapse" id="collapsibleNavId">
            <ul class="navbar-nav me-auto mt-2 mt-lg-0">
              <li class="nav-item">
                <a class="nav-link" href="Home.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="show.php">ShowProduct</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="About.php">About Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Contact.php">Contact Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Ty.php">Thank You!</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Comming.php">Comming Soon</a>
              </li>
            </ul>
            <form class="d-flex my-2 my-lg-0" action="reg.php">
              <button class="btn btn-danger my-2 my-sm-0 me-2" type="submit">
                Register
              </button>
            </form>
            <form class="d-flex my-2 my-lg-0" action="login.php">
              <button class="btn btn-danger my-2 my-sm-0" type="submit">
                Login
              </button>
            </form>
          </div>
        </div>
      </nav>
    </header>

    <h2 class="text-center text-dark mt-5">Edit</h2>
      <div style="background-color: rgb(135, 147, 183)" class="container text-center image-fluid rounded col-7 p-5 mt-4 image">
        <form action="" method="post">
          
             <div class=" form-floating mb-3">
              <input
                type="hidden"
                class="form-control"
                name="id"
                id=""
                placeholder=""
                value="<?=$user["Id"]?>"
              />
             </div>
             
             <div class="form-floating mb-3">
            <input
              type="text"
              class="form-control"
              name="product"
              id="formId1"
              placeholder=""
              value="<?=$user["Product"]?>"
            />
            <label for="formId1">Product</label>
          </div>
             <div class=" form-floating mb-3">
              <!-- <label for="" class="form-label">Salary</label> -->
              <input
                type="text"
                class="form-control"
                name="title"
                id=""
                placeholder=""
                value="<?=$user["Title"]?>"
              />
              <label for="" class="form-label">Title</label>
             </div>
             <div class=" form-floating mb-3">
              
              <input
                type="number"
                class="form-control"
                name="qty"
                id=""
                placeholder=""
                value="<?=$user["Qty"]?>"
              />
              <label for="" class="form-label">Quantity</label>
             </div>
             <div class=" form-floating mb-3">
              
              <input
                type="number"
                class="form-control"
                name="amount"
                id=""
                placeholder=""
                value="<?=$user["Amount"]?>"
              />
              <label for="" class="form-label">Amount</label>
             </div>
             <div class="text-center pt-3">
             <button
              type="submit"
              class="btn btn-primary me-5"
             >
              Submit
             </button>
             <a  class="" href="insert.php">Back</a>
             </div>
        </form>
      </div>
    <main>
      <!--Pagination-->
      <div class="d-flex justify-content-center mt-5">
        <nav aria-label="Page navigation">
          <ul class="pagination">
            <li class="page-item disabled">
              <a class="page-link" href="#" aria-label="Previous">
                <span aria-hidden="true">&laquo;</span>
              </a>
            </li>
            <li class="page-item" aria-current="page">
              <a class="page-link" href="Home.php">1</a>
            </li>
            <li class="page-item active">
              <a class="page-link" href="show.php">2</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="About.php">3</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="Contact.php">4</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="Ty.php">5</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="Comming.php">6</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="reg.php">7</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="#" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </main>
    <footer class="text-center bg-dark text-white py-3">
      <!-- place footer here -->
      <h4>&copy; All Rights Are Reserved</h4>
    </footer>
    <!-- Bootstrap JavaScript Libraries -->
    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
      integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
      crossorigin="anonymous"
    ></script>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
      integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
