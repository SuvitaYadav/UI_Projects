<?php
  include 'DB.php';
  session_start();
  if($_SERVER['REQUEST_METHOD'] == "POST"){
    $uname = $_POST["uname"];
    $pass = $_POST["pass"];

    $sql = $conn->prepare("select id,password from myglamm where username=?");
    $sql->bind_param("s", $uname);

    $sql->execute();

    $sql->store_result();

    $sql->bind_result($id, $password);

    if($sql->fetch() && password_verify($pass, $password)){
      $_SESSION["username"] = $uname;
      header("Location:Home.php");
    }
    else{
    echo "Please enter a valid credential...";
    }
    
  }

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS v5.2.1 -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
      crossorigin="anonymous"
    />
  </head>

  <body>
    <header>
      <!-- place navbar here -->
      <nav class="navbar navbar-expand-sm navbar-light bg-light">
        <div class="container">
          <img
            src="https://files.myglamm.com/site-images/original/MG_1.png"
            class="img-fluid ps-5 pe-5"
            alt=""
            height="300px"
            width="300px"
          />

          <div class="collapse navbar-collapse" id="collapsibleNavId">
            <ul class="navbar-nav me-auto mt-2 mt-lg-0">
              <li class="nav-item">
                <a class="nav-link" href="Home.php"
                  >Home <span class="visually-hidden">(current)</span></a
                >
              </li>
              <li class="nav-item">
                <a class="nav-link" href="SkinCare.php"
                  >SkinCare<span class="visually-hidden">(current)</span></a
                >
              </li>
              <li class="nav-item">
                <a class="nav-link" href="About.php">About Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Contact.php">Contact Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Ty.php">Thank You!</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Comming.php">Comming Soon</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
    <main>
      <h2 style="color: rgb(124, 124, 193); margin-top: 5%" class="text-center">
        Login
      </h2>
      <div class="container col-4 mt-4">
        <form action="" method="POST">
          <div class="form-floating mb-3">
            <input
              type="text"
              class="form-control"
              name="uname"
              id="formId1"
              placeholder=""
              required
            />
            <label for="formId1">Username</label>
          </div>

          <div class="form-floating mb-3">
            <input
              type="password"
              class="form-control"
              name="pass"
              id="formId1"
              placeholder=""
              required
            />
            <label for="formId1">Password</label>
          </div>
          <div class="text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
        <div>
              <h5 class="text-center mt-1">
                Don't have an account please register here
                <a style="color: black" href="reg.php">Register</a>
              </h5>
            </div>
      </div>
    </main>
    <footer class="text-center bg-dark text-white py-3 mt-3">
      <!-- place footer here -->
      <h4>&copy; All Rights Are Reserved</h4>
    </footer>
    <!-- Bootstrap JavaScript Libraries -->
    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
      integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
      crossorigin="anonymous"
    ></script>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
      integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
      crossorigin="anonymous"
    ></script>
  </body>
</html>


