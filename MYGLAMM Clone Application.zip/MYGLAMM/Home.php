<?php

  session_start();
  if (!isset($_SESSION["username"])){
    header("Location:login.php");
  }

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS v5.2.1 -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
    <header>
      <!-- place navbar here -->
      <nav class="navbar navbar-expand-sm navbar-light bg-light">
        <div class="container">
          <img
            src="https://files.myglamm.com/site-images/original/MG_1.png"
            class="img-fluid ps-5 pe-5"
            alt=""
            height="300px"
            width="300px"
          />

          <div class="collapse navbar-collapse" id="collapsibleNavId">
            <ul class="navbar-nav me-auto mt-2 mt-lg-0">
              <li class="nav-item">
                <a class="nav-link active" href="Home.php" aria-current="page"
                  >Home <span class="visually-hidden">(current)</span></a
                >
              </li>
              <li class="nav-item">
                <a class="nav-link" href="show.php"
                  >ShowProduct<span class="visually-hidden">(current)</span></a
                >
              </li>
              <li class="nav-item">
                <a class="nav-link" href="About.php">About Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Contact.php">Contact Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Ty.php">Thank You!</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Comming.php">Comming Soon</a>
              </li>
            </ul>
            <div class="logoutButton">
            <a href="logout.php" onclick="return confirm('Are you sure you want to logout?');"><button type="submit" class="btn btn-danger my-1">LogOut</button></a>
            </div>
          
          </div>
        </div>
      </nav>
    </header>
    <p style="margin-right:30px" class="d-flex justify-content-end"> Welcome, <b>   <?php echo $_SESSION["username"]?> </b> to myglamm store </p>
    <main>
      <!-- carousel -->
      <h2 class="text-center text-primary mt-2">
        Welcome to the India’s No. 1 Makeup Brand
      </h2>

      <div class="container mt-3">
        <div id="carouselId" class="carousel slide" data-bs-ride="carousel">
          <ol class="carousel-indicators">
            <li
              data-bs-target="#carouselId"
              data-bs-slide-to="0"
              class="active"
              aria-current="true"
              aria-label="First slide"
            ></li>
            <li
              data-bs-target="#carouselId"
              data-bs-slide-to="1"
              aria-label="Second slide"
            ></li>
            <li
              data-bs-target="#carouselId"
              data-bs-slide-to="2"
              aria-label="Third slide"
            ></li>
            <li
              data-bs-target="#carouselId"
              data-bs-slide-to="3"
              aria-label="Fourth slide"
            ></li>
            <li
              data-bs-target="#carouselId"
              data-bs-slide-to="4"
              aria-label="Fiveth slide"
            ></li>
          </ol>
          <div class="carousel-inner col-6" role="listbox">
            <div class="carousel-item active">
              <img
                src="https://s3.ap-south-1.amazonaws.com/files.myglamm.com-dr/site-images/original/2240x614px.jpg"
                class="w-100 d-block"
                alt="First slide"
                height="350px"
                width="409px"
              />
            </div>
            <div class="carousel-item">
              <img
                src="https://s3.ap-south-1.amazonaws.com/files.myglamm.com-dr/site-images/original/Homepage-desktop---1920-x-527_2.png"
                class="w-100 d-block"
                alt="Second slide"
                height="350px"
                width="409px"
              />
            </div>
            <div class="carousel-item">
              <img
                src="https://s3.ap-south-1.amazonaws.com/files.myglamm.com-dr/site-images/original/1920-x-527zcfd.jpg"
                class="w-100 d-block"
                alt="Third slide"
                height="350px"
                width="409px"
              />
            </div>
            <div class="carousel-item">
              <img
                src="https://s3.ap-south-1.amazonaws.com/files.myglamm.com-dr/site-images/original/1920x527px.jpg"
                class="w-100 d-block"
                alt="Fourth slide"
                height="350px"
                width="409px"
              />
            </div>
            <div class="carousel-item">
              <img
                src="https://s3.ap-south-1.amazonaws.com/files.myglamm.com-dr/site-images/original/Homepage-desktop---1920-x-527-1_2.png"
                class="w-100 d-block"
                alt="Fiveth slide"
                height="350px"
                width="409px"
              />
            </div>
          </div>
          <button
            class="carousel-control-prev"
            type="button"
            data-bs-target="#carouselId"
            data-bs-slide="prev"
          >
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button
            class="carousel-control-next"
            type="button"
            data-bs-target="#carouselId"
            data-bs-slide="next"
          >
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>
      </div>

      <!--Service-->

      <h1
        style="text-transform: uppercase"
        class="text-center text-danger mt-5"
      >
        A POUT FOR EVERY MOOD
      </h1>

      <div class="container d-flex flex-row mt-2 p-3">
        <div class="me-2">
          <img
            src="https://files.myglamm.com/site-images/400x400/crm1_5.jpg"
            alt=""
            height="190px"
            width="300px"
          />
        </div>
        <div class="mx-3 ms-4">
          <img
            src="https://files.myglamm.com/site-images/400x400/mat1.jpg"
            alt=""
            height="190px"
            width="300px"
          />
        </div>
        <div class="mx-3">
          <img
            src="https://files.myglamm.com/site-images/400x400/all1.jpg"
            alt=""
            height="190px"
            width="300px"
          />
        </div>
        <div class="mx-3">
          <img
            src="https://files.myglamm.com/site-images/400x400/al1.jpg"
            alt=""
            height="190px"
            width="300px"
          />
        </div>
      </div>

      <h4
        style="
          text-transform: uppercase;
          background-image: linear-gradient(
            180deg,
            transparent 60%,
            #ec1d6b 30px
          );
          width: max-content;
          line-height: 2rem;
          padding-left: 0.375rem;
          padding-right: 0.375rem;
          margin-left: auto;
          margin-right: auto;
        "
        class="text-center mt-5"
      >
        Latest Glamm Launches
      </h4>
      <h4 class="text-center">Add Product <a href="insert.php">here</a></h4>
      <div class="container mt-5 my-3">
        <div class="row justify-content-center align-items-center g-2">
          <div
            class="col"
            style="
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
            "
          >
            <div class="card">
              <img
                class="card-img-top"
                src="https://files.myglamm.com/site-images/400x400/kl1_1.jpg"
                alt="Lipstick"
                height="350px"
              />
              <div class="card-body">
                <h4 class="card-title">Matte Plumping Lipstick</h4>
                <p class="card-text">
                  MyGlamm POUT by Karan Johar Intense Matte Plumping Lipstick -
                  Controversial Pout (Fuschia Pink Shade) | Highly Pigmented,
                  Soft Matte Lipstick, Long Lasting & Lightweight
                </p>
                <div>
                  <a
                    name=""
                    id=""
                    class="btn btn-primary"
                    href="insert.php"
                    role="button"
                    >Add Product</a
                  >
                </div>
              </div>
            </div>
          </div>
          <div
            class="col"
            style="
              text-overflow: ellipsis;
              overflow: hidden;
              white-space: nowrap;
            "
          >
            <div class="card">
              <img
                class="card-img-top"
                src="https://www.myglamm.com/_next/image?url=https%3A%2F%2Ffiles.myglamm.com%2Fsite-images%2F800x800%2FAMD1.jpg&w=384&q=75"
                alt="Huts"
                height="350px"
              />
              <div class="card-body">
                <h4 class="card-title">BB Skin Tint</h4>
                <p class="card-text">
                  Manish Malhotra BB Skin Tint With SPF 50 PA+++ - Amber Dream |
                  Hydrating, Light to Medium Coverage, Skin Brightening BB Cream
                  For Dark Skin
                </p>
                <div>
                  <a
                    name=""
                    id=""
                    class="btn btn-primary"
                    href="insert.php"
                    role="button"
                    >Add Product</a
                  >
                </div>
              </div>
            </div>
          </div>
          <div
            class="col"
            style="
              text-overflow: ellipsis;
              overflow: hidden;
              white-space: nowrap;
            "
          >
            <div class="card">
              <img
                class="card-img-top"
                src="https://files.myglamm.com/site-images/800x800/BRSGt-(1).jpg"
                alt="Temple"
                height="350px"
              />
              <div class="card-body">
                <h4 class="card-title">Sheet Mask</h4>
                <p class="card-text">
                  MyGlamm K.Play Mandarin Brightening Sheet Mask
                </p>
                <div>
                  <a
                    name=""
                    id=""
                    class="btn btn-primary"
                    href="insert.php"
                    role="button"
                    >Add Product</a
                  >
                </div>
              </div>
            </div>
          </div>
          <div
            class="col"
            style="
              text-overflow: ellipsis;
              overflow: hidden;
              white-space: nowrap;
            "
          >
            <div class="card">
              <img
                class="card-img-top"
                src="https://www.myglamm.com/_next/image?url=https%3A%2F%2Ffiles.myglamm.com%2Fsite-images%2F800x800%2FFLKIU.jpg&w=384&q=75"
                alt="Temple"
                height="350px"
              />
              <div class="card-body">
                <h4 class="card-title">XOXO Fragrance</h4>
                <p class="card-text">
                  MyGlamm LIT XOXO Fragrance - Flirty Perfume - 25ml
                </p>
                <div>
                  <a
                    name=""
                    id=""
                    class="btn btn-primary"
                    href="insert.php"
                    role="button"
                    >Add Product</a
                  >
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="container">
        <div>
          <img
            src="https://files.myglamm.com/site-images/768x432/Untitled-design-(69).png"
            alt=""
            height="350px"
            width="100%"
          />
        </div>
      </div>

      <h3
        style="
          text-transform: uppercase;
          background-image: linear-gradient(
            180deg,
            transparent 60%,
            #ec1d6b 30px
          );
          width: max-content;
          line-height: 2rem;
          padding-left: 0.375rem;
          padding-right: 0.375rem;
          margin-left: auto;
          margin-right: auto;
        "
        class="text-center mt-5"
      >
        In The SpotLight
      </h3>

      <div class="container d-flex flex-row mt-3">
        <div class="me-2">
          <img
            src="https://files.myglamm.com/site-images/768x432/Untitled-design-(53)_1.png"
            alt=""
            height="300px"
            width="410px"
          />
        </div>
        <div class="mx-2 ms-4">
          <img
            src="https://files.myglamm.com/site-images/768x432/Untitled-design-(73).png"
            alt=""
            height="300px"
            width="410px"
          />
        </div>

        <div class="mx-2 ms-4">
          <img
            src="https://files.myglamm.com/site-images/768x432/https---nucleus_1.png"
            alt=""
            height="300px"
            width="410px"
          />
        </div>
      </div>
      <h3
        style="
          text-transform: uppercase;
          background-image: linear-gradient(
            180deg,
            transparent 60%,
            #ec1d6b 30px
          );
          width: max-content;
          line-height: 2rem;
          padding-left: 0.375rem;
          padding-right: 0.375rem;
          margin-left: auto;
          margin-right: auto;
        "
        class="text-center mt-5"
      >
        Bestsellers
      </h3>

      <div class="container mt-5 my-3">
        <div class="row justify-content-center align-items-center g-2">
          <div
            class="col"
            style="
              text-overflow: ellipsis;
              overflow: hidden;
              white-space: nowrap;
            "
          >
            <div class="card">
              <img
                class="card-img-top"
                src="https://files.myglamm.com/site-images/400x400/ppypn1.jpg"
                alt="Lipstick"
                height="350px"
              />
              <div class="card-body">
                <h4 class="card-title">Soft Matte Lipstick</h4>
                <p class="card-text">
                  Manish Malhotra Soft Matte Lipstick - Poppy Pink (Neon Pink
                  Shade) | Long Lasting, Hydrating, Moisturising, Matte Finish
                  Creamy Lipstick
                </p>
                <p style="font-weight: bold">₹599</p>
                <div>
                  <a
                    name=""
                    id=""
                    class="btn btn-primary"
                    href="lips.php"
                    role="button"
                    >View Product</a
                  >
                </div>
              </div>
            </div>
          </div>
          <div
            class="col"
            style="
              text-overflow: ellipsis;
              overflow: hidden;
              white-space: nowrap;
            "
          >
            <div class="card">
              <img
                class="card-img-top"
                src="https://files.myglamm.com/site-images/400x400/Manht1.jpg"
                alt="Huts"
                height="350px"
              />
              <div class="card-body">
                <h4 class="card-title">LIT Creamy Matte Lipstick</h4>
                <p class="card-text">
                  MyGlamm LIT Creamy Matte Lipstick - Manhattan (Rosy Pink
                  Shade) | Long Lasting, Creamy, Demi-matte Finish Slim Lipstick
                  (3.7g)
                </p>
                <p style="font-weight: bold">₹327</p>
                <div>
                  <a
                    name=""
                    id=""
                    class="btn btn-primary"
                    href="lips.php"
                    role="button"
                    >View Product</a
                  >
                </div>
              </div>
            </div>
          </div>
          <div
            class="col"
            style="
              text-overflow: ellipsis;
              overflow: hidden;
              white-space: nowrap;
            "
          >
            <div class="card">
              <img
                class="card-img-top"
                src="https://files.myglamm.com/site-images/400x400/Indig1_1.jpg"
                alt="Temple"
                height="350px"
              />
              <div class="card-body">
                <h4 class="card-title">Kajal</h4>
                <p class="card-text">
                  MyGlamm SUPERFOODS Kajal - Indigo (Deep Purple Shade) | Long
                  Lasting, Smudge-proof, Waterproof Eye Kajal Pencil with
                  Superfood Extracts (0.35g)
                </p>
                <p style="font-weight: bold">₹245</p>
                <div>
                  <a
                    name=""
                    id=""
                    class="btn btn-primary"
                    href="lips.php"
                    role="button"
                    >View Product</a
                  >
                </div>
              </div>
            </div>
          </div>
          <div
            class="col"
            style="
              text-overflow: ellipsis;
              overflow: hidden;
              white-space: nowrap;
            "
          >
            <div class="card">
              <img
                class="card-img-top"
                src="https://files.myglamm.com/site-images/400x400/z1_1.jpg"
                alt="Temple"
                height="350px"
              />
              <div class="card-body">
                <h4 class="card-title">Velvet Matte Liquid Lipstick</h4>
                <p class="card-text">
                  MyGlamm LIT Velvet Matte Liquid Lipstick - Rare (Ripe Apricot
                  Shade) | Moisturising, Hydrating, High Coverage Liquid
                  Lipstick
                </p>
                <p style="font-weight: bold">₹316</p>
                <div>
                  <a
                    name=""
                    id=""
                    class="btn btn-primary"
                    href="lips.php"
                    role="button"
                    >View Product</a
                  >
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <h3
        style="
          text-transform: uppercase;
          background-image: linear-gradient(
            180deg,
            transparent 60%,
            #ec1d6b 30px
          );
          width: max-content;
          line-height: 2rem;
          padding-left: 0.375rem;
          padding-right: 0.375rem;
          margin-left: auto;
          margin-right: auto;
        "
        class="text-center mt-5"
      >
        Shop from Categories
      </h3>

      <div style="margin-left: 5%" class="container d-flex flex-row mt-3 p-1">
        <div class="mx-1 p-3">
          <img
            src="https://media.istockphoto.com/id/1272479912/photo/close-up-portrait-of-young-and-beautiful-woman.jpg?s=612x612&w=0&k=20&c=2sR8vedKCijWux6TFpT6YoZeDDeyaqPt0_ZCrOzAzJg="
            alt=""
            height="130px"
            width="130px"
            class="image-fluid rounded-circle"
          />
          <p style="font-weight: bold" class="text-center p-3">Skin</p>
        </div>
        <div class="mx-1 p-3">
          <img
            src="https://t3.ftcdn.net/jpg/02/13/93/28/360_F_213932841_oq7qxsnA5wR7hr8o69ZVGO2mJmW9QvB5.jpg"
            alt=""
            height="130px"
            width="130px"
            class="image-fluid rounded-circle"
          />
          <p style="font-weight: bold" class="text-center p-3">Lips</p>
        </div>
        <div class="mx-1 p-3">
          <img
            src="https://media.istockphoto.com/id/1055099140/photo/making-hairstory-everyday-with-gorgeous-hair.jpg?s=612x612&w=0&k=20&c=x-Hxtr85HmZ_U5o7-KNzLCNi63drTeijFnuFcpz5kUU="
            alt=""
            height="130px"
            width="130px"
            class="image-fluid rounded-circle"
          />
          <p style="font-weight: bold" class="text-center p-3">Hair</p>
        </div>

        <div class="mx-1 p-3">
          <img
            src="https://t4.ftcdn.net/jpg/01/27/68/27/360_F_127682737_2zQEj1IUv1J6cSUrQRYwAklzLzDzVNpN.jpg"
            alt=""
            height="130px"
            width="130px"
            class="image-fluid rounded-circle"
          />
          <p style="font-weight: bold" class="text-center p-3">Eyes</p>
        </div>
        <div class="mx-1 p-3">
          <img
            src="https://media.istockphoto.com/id/1442556244/photo/portrait-of-young-beautiful-woman-with-perfect-smooth-skin-isolated-over-white-background.jpg?s=612x612&w=0&k=20&c=4S7HufG4HDXznwuxFdliWndEAcWGKGvgqC45Ig0Zqog="
            alt=""
            height="130px"
            width="130px"
            class="image-fluid rounded-circle"
          />
          <p style="font-weight: bold" class="text-center p-3">Face</p>
        </div>
        <div class="mx-1 p-3">
          <img
            src="https://cdn.shopify.com/s/files/1/0529/0619/7148/files/Square_nail_shape_480x480.jpg?v=1726148781"
            alt=""
            height="130px"
            width="130px"
            class="image-fluid rounded-circle"
          />
          <p style="font-weight: bold" class="text-center p-3">Nails</p>
        </div>
        <div class="mx-1 p-3">
          <img
            src="https://media.istockphoto.com/id/1212717457/photo/disinfecting-hands-taking-disinfection-alcohol-gel-on-hands-in-white-light-to-prevent-virus.jpg?s=612x612&w=0&k=20&c=qnkR5jruhgTJWW7XKXLXbfODMFNeU6T-ffgCnbjbmVU="
            alt=""
            height="130px"
            width="130px"
            class="image-fluid rounded-circle"
          />
          <p
            style="font-weight: bold; padding-top: 12%; padding-left: 7%"
            class=""
          >
            Sanitizing Care
          </p>
        </div>
        <div class="mx-1 p-3">
          <a href="https://www.myglamm.com/buy/makeup/lips">
          <img
            src="https://media.istockphoto.com/id/1141213118/photo/smiling-female-rubbing-body-with-foam.jpg?s=612x612&w=0&k=20&c=XtCgHPKv78vuDvrpad11ifsbRHT-4_XMq6qhdbeChJk="
            alt=""
            height="130px"
            width="130px"
            class="image-fluid rounded-circle"
          />
          </a>
          
          <p style="font-weight: bold" class="text-center p-3">Bath & Body</p>
        </div>
      </div>
      
      <!--pagination-->
      <div class="d-flex justify-content-center mt-5">
        <nav aria-label="Page navigation">
          <ul class="pagination">
            <li class="page-item disabled">
              <a class="page-link" href="#" aria-label="Previous">
                <span aria-hidden="true">&laquo;</span>
              </a>
            </li>
            <li class="page-item active" aria-current="page">
              <a class="page-link" href="Home.php">1</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="show.php">2</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="About.php">3</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="Contact.php">4</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="Ty.php">5</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="Comming.php">6</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="reg.php">7</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="#" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </main>
    <footer class="text-center bg-dark text-white py-3">
      <!-- place footer here -->
      <h4>&copy; All Rights Are Reserved</h4>
    </footer>
    <!-- Bootstrap JavaScript Libraries -->
    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
      integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
      crossorigin="anonymous"
    ></script>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
      integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
