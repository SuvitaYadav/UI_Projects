<?php
  include 'DB.php';
  if($_SERVER['REQUEST_METHOD'] =="POST"){
    $name = $_POST["name"];
    $phone = $_POST["phone"];
    $mail = $_POST["mail"];
    $uname = $_POST["uname"];
    $pass = password_hash($_POST["pass"], PASSWORD_BCRYPT);
    $sql = $conn->prepare("insert into myglamm(name,phone,email,username,password) values(?,?,?,?,?)");
    $sql->bind_param("sisss", $name, $phone, $mail, $uname, $pass);
    if($sql->execute()){
      header("Location:login.php");
    }
    else{
      header("Location:reg.php");
    }
  }
?>
<!doctype html>
<html lang="en">
  <head>
    <title>MyglammRegister</title>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS v5.2.1 -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
      crossorigin="anonymous"
    />
  </head>

  <body>
    <header>
      <!-- place navbar here -->
    </header>
    <main>
      <div class="container">
        <h3 class="text-center text-success mt-2">Register With Us!!</h3>
        <div class="row justify-content-center align-items-center">
          <div
            style="background-color: rgb(139, 145, 152)"
            class="container p-4 col-6 image-fluid rounded"
          >
            <form action="" method="POST">
              <div class="form-floating mb-3">
                <input
                  type="text"
                  class="form-control"
                  name="name"
                  id="regName"
                  placeholder=""
                  required
                />
                <label for="formId1">Name</label>
              </div>

              <div class="form-floating mb-3">
                <input
                  type="number"
                  class="form-control"
                  name="phone"
                  id="regPhone"
                  placeholder=""
                  required
                />
                <label for="formId1">Phone</label>
              </div>

              <div class="form-floating mb-3">
                <input
                  type="email"
                  class="form-control"
                  name="mail"
                  id="regEmail"
                  placeholder=""
                  required
                />
                <label for="formId1">Email</label>
              </div>

              <div class="form-floating mb-3">
                <input
                  type="text"
                  class="form-control"
                  name="uname"
                  id="regUser"
                  placeholder=""
                  required
                />
                <label for="formId1">Username</label>
              </div>

              <div class="form-floating mb-3">
                <input
                  type="password"
                  class="form-control"
                  name="pass"
                  id="regPass"
                  placeholder=""
                  required
                />
                <label for="formId1">Password</label>
              </div>
              <div class="text-center image-fluid rounded">
                <button
                  type="submit"               
                  class="btn btn-primary mt-1"
                >
                  Register
                </button>
              </div>
              <p class="text-center text-success mt-2" id="regMessage"></p>
            </form>
            <div>
              <h5 class="text-center mt-1">
                Already have an account please login here
                <a style="color: black" href="login.php">Login</a>
              </h5>
            </div>
          </div>
          <div class="col-6">
            <img
              src="https://img.freepik.com/premium-vector/online-registration-illustration-design-concept-websites-landing-pages-other_108061-938.jpg"
              class="img-fluid rounded-top"
              alt=""
              height="1000px"
              width="800px"
              title="Register"
            />
          </div>
        </div>
      </div>
    </main>
    <footer>
      <!-- place footer here -->
    </footer>
    <!-- Bootstrap JavaScript Libraries -->
    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
      integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
      crossorigin="anonymous"
    ></script>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
      integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
      crossorigin="anonymous"
    ></script>
  </body>
</html>


