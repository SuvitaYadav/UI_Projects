<?php
  require('vendor/autoload.php');

  $conn = mysqli_connect('localhost','root','','e1_php');

  $result = mysqli_query($conn,"select * from glammin");

  if(mysqli_num_rows($result) > 0){
    $html = '<style></style><table border="1"; class="table">';
    $html.='<tr><td>ID</td><td>PRODUCT</td><td>TITLE</td><td>Qauntity</td><td>Amount</td></tr>';

    while($row = mysqli_fetch_array($result)){
      $html.= '<tr><td>'.$row['Id'].'</td><td>'.$row['Product'].'</td><td>'.$row['Title'].'</td><td>'.$row['Qty'].'</td><td>'.$row['Amount'].'</td></tr>';
    }
    $html.='</table>';
  }
    else{
      $html.="Data not found";
    }
  
    // $html = '<h1 style="color: green">Example</h1>';
    // $html.= "Hello <em>Suvita</em>";
    // $html.= '<img src="MG_1.png">';

    $mpdf = new \Mpdf\Mpdf();
    $mpdf->WriteHTML($html);
    
    $file='Myglamm_invoice/'.time().'.pdf';
    $mpdf->output($file,'I');
?>