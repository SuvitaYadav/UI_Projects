<?php

  header("Content-Type: application/vnd.ms-excel");
  header("Content-Disposition: attachment; Filename = MyGlamm.xls");

  require 'show.php';

?>