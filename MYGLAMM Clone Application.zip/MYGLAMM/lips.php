<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS v5.2.1 -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
      crossorigin="anonymous"
    />
  </head>

  <body>
    <header>
      <!-- place navbar here -->
    </header>
    <main>
      <div class="carousel-inner col-6 mt-5 mx-5 mb-3">
        <div class="container text-center">
        <button type="button" class="p-1 flex items-center justify-center" data-index="0" style="height: 80px; scroll-snap-align: start; scroll-snap-stop: always; flex-shrink: 0;">
          <img decoding="async" src="https://files.myglamm.com/site-images/1200x1200/kl1_1.jpg" class="ImgComponent ImgFadeIn" id alt="kl1_1.jpg" width="72">
        </button>
        <button type="button" class="p-1 flex items-center justify-center" data-index="0" style="height: 80px; scroll-snap-align: start; scroll-snap-stop: always; flex-shrink: 0;">
          <img decoding="async" src="https://files.myglamm.com/site-images/800x800/kl10.jpg" class="ImgComponent ImgFadeIn" id alt="kl2_1.jpg" width="72">
        </button>
        <button type="button" class="p-1 flex items-center justify-center" data-index="0" style="height: 80px; scroll-snap-align: start; scroll-snap-stop: always; flex-shrink: 0;">
          <img decoding="async" src="https://files.myglamm.com/site-images/800x800/kl3_1.jpg" width="72">
        </button>
        <button type="button" class="p-1 flex items-center justify-center" data-index="0" style="height: 80px; scroll-snap-align: start; scroll-snap-stop: always; flex-shrink: 0;">
          <img decoding="async" src="https://files.myglamm.com/site-images/800x800/kl5_2.jpg" class="ImgComponent ImgFadeIn" id alt="kl5_2.jpg" width="72">
        </button>
        <button type="button" class="p-1 flex items-center justify-center" data-index="0" style="height: 80px; scroll-snap-align: start; scroll-snap-stop: always; flex-shrink: 0;">
          <img decoding="async" src="https://files.myglamm.com/site-images/800x800/kl9.jpg" class="ImgComponent loading-Img" id alt="" width="72">
        </button>
        <button type="button" class="p-1 flex items-center justify-center" data-index="0" style="height: 80px; scroll-snap-align: start; scroll-snap-stop: always; flex-shrink: 0;">
          <img decoding="async" src="https://files.myglamm.com/site-images/800x800/kl6_2.jpg" class="ImgComponent loading-Img" id alt="" width="72">
        </button>
        </div>
      </div>
    
      <aside
        style="
          border-top: 3px solid rgb(237, 46, 20);
          border-bottom: 3px solid rgb(237, 46, 20);
        "
      >
        <div class="container mt-5">
          <div class="row justify-content-center align-items-center g-2">
            <div class="col-4">
              <img
                src="https://www.myglamm.com/_next/image?url=https%3A%2F%2Ffiles.myglamm.com%2Fsite-images%2F800x800%2Fkl6_2.jpg&w=750&q=75"
                class="img-fluid rounded-top"
                alt=""
                width="350px"
                height="250px"
              />
            </div>
            <div class="col-6 ps-5">
              <h3>MyGlamm POUT by Karan Johar Intense Matte Plumping Lipstick - Controversial Pout (Fuschia Pink Shade) | Highly Pigmented, Soft Matte Lipstick, Long Lasting & Lightweight</h3>
              <p>₹798</p>
              <p>(MRP incl. of all taxes)</p>
              <p style="background-color: rgba(244,244,244)">You will receive <strong>cashback worth ₹33</strong> as myglammPOINTS on this purchase</p>
              <form class="d-flex my-2 my-lg-0" action="insert.php">
              <button class="btn my-2 my-sm-0" style="background-color: palevioletred" type="submit">
                Add To Bag
              </button>
            </form>
            </div>            
          </div>
        </div>
      </aside>
      <h3
          style="
            color: black;
            font-weight: bold;
            text-transform: uppercase;
            text-decoration: underline;
          "
          class="text-center mt-3"
        >
          Watch & Learn
        </h3>
      <div class="container">
          <div class="row justify-content-center align-items-center g-2">
            <div class="col-6">
              <iframe
                width="560"
                height="315"
                src="https://www.youtube.com/embed/11q9itZtgs8" 
                title="Pout Loud As We Are Going Matte 💋" 
                frameborder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen>
              </iframe>
            </div>
            <div class="col-6 ps-5">
            <h4 class="mt-3">Pout Loud As We Are Going Matte 💋</h4>
              <p>
              Introducing the all-new 'Pout' Matte collection – where intense matte meets endless confidence! Matte made in heaven with a side of extra plump 💋 With just one stroke, these lipsticks deliver bold, high-impact color for a look that speaks volumes. The soft velvety texture provides a plumping effect, leaving your lips looking fuller and flawless without any dryness. Get an intense matte finish with a single swipe and instant plumping effect in 10 vibrant shades 💄 Elevate your lip game with the ultimate matte finish and let your confidence shine ✨ #PoutLikeKaranJohar #MyGlammxPout #MyGlamm ------------------------------------------------------------------------------------------------------------------------ Visit The Website - https://bit.ly/2WcrCFW Click here for Attractive Offers - https://bit.ly/3gO4C8a ------------------------------------------------------------------------------------------------------------------------ Download the MyGlamm app here: Android: https://bit.ly/309O1VA IOS: https://apple.co/32diu87 ------------------------------------------------------------------------------------------------------------------------ Like Our Page for Daily Dose of Beauty. Facebook: https://bit.ly/3j8k9BU Instagram: https://bit.ly/304mV2i Twitter: https://bit.ly/2C5MLeh
              </p>
            </div>
          </div>
        </div>
        
    </main> 
    <footer>
      <!-- place footer here -->
    </footer>
    <!-- Bootstrap JavaScript Libraries -->
    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
      integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
      crossorigin="anonymous"
    ></script>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
      integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
