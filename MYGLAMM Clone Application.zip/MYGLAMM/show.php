<?php
  include 'DB.php';
  $result = $conn->query('Select * from glammin'); ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
  </head>
  <body>
    <img src="MG_1.png" alt="" />
    <h1>Selected Items</h1>
    <table border="1">
      <tr>
        <th>ID</th>
        <th>Product</th>
        <th>Title</th>
        <th>Qty</th>
        <th>Amount</th>
        <th>Action</th>
      </tr>

      <?php
      while ($row = $result->fetch_assoc()){?>
      <tr>
        <td><?=$row["Id"]?></td>
        <td><?=$row["Product"]?></td>
        <td><?=$row["Title"]?></td>
        <td><?=$row["Qty"]?></td>
        <td><?=$row["Amount"]?></td>
        <td><a href="SkinCare.php?Id=<?= $row["Id"] ?>"><button type="submit" class="text-light bg-primary image-fluid rounded ms-2">Edit</button></a>
        <a href="delete.php?Id=<?= $row["Id"] ?>" onclick="return confirm('Are you sure you want to delete?');"><button type="submit" class="text-light bg-primary image-fluid rounded ms-3">Delete</button></a></td>
      </tr>

      <?php } ?>
    </table>
    <a  class="mt-3" href="insert.php">Back</a>
    <a  class="mt-3" href="Home.php">Home</a>

  </body>
</html>

