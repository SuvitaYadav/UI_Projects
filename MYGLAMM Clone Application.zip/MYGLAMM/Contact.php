<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS v5.2.1 -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
      crossorigin="anonymous"
    />
  </head>

  <body>
    <header>
      <!-- place navbar here -->
      <nav class="navbar navbar-expand-sm navbar-light bg-light">
        <div class="container">
          <img
            src="https://files.myglamm.com/site-images/original/MG_1.png"
            class="img-fluid ps-5 pe-5"
            alt=""
            height="300px"
            width="300px"
          />

          <div class="collapse navbar-collapse" id="collapsibleNavId">
            <ul class="navbar-nav me-auto mt-2 mt-lg-0">
              <li class="nav-item">
                <a class="nav-link" href="Home.php" aria-current="page"
                  >Home <span class="visually-hidden">(current)</span></a
                >
              </li>
              <li class="nav-item">
                <a class="nav-link" href="show.php"
                  >ShowProduct<span class="visually-hidden">(current)</span></a
                >
              </li>
              <li class="nav-item">
                <a class="nav-link" href="About.php">About Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="Contact.php">Contact Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Ty.php">Thank You!</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Comming.php">Comming Soon</a>
              </li>
            </ul>
            <form class="d-flex my-2 my-lg-0" action="reg.php">
              <button class="btn btn-danger my-2 my-sm-0 me-2" type="submit">
                Register
              </button>              
            </form>
            <form class="d-flex my-2 my-lg-0" action="login.php">
              <button class="btn btn-danger my-2 my-sm-0" type="submit">
                Login
              </button>
            </form>
          </div>
        </div>
      </nav>
    </header>
    <main>
      <div class="container col-6">
        <div class="row justify-content-center align-items-center g-2">
          <h3 class="text-center text-danger">Company Details</h3>
          <!--table -->
          <div class="container col-5">
            <div class="table-responsive">
              <table class="table">
                <thead class="table-info">
                  <tr>
                    <th scope="col">Name</th>
                    <th scope="col">MyGlamm</th>
                  </tr>
                </thead>
                <tbody>
                  <tr class="table-secondary">
                    <td scope="row">Phone</td>
                    <td>750xxxxxx42</td>
                  </tr>
                  <tr class="table-secondary">
                    <td scope="row">Address</td>
                    <td>Goregaon</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <h3 class="text-center mt-4">Come Find Us Here !!!!</h3>

          <div class="container text-center my-4">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60292.153559361606!2d72.82782670799584!3d19.183860652798195!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b5ce2b93d7db%3A0x879a5e5cfe9bb7a8!2sMalad%2C%20Malad%20East%2C%20Mumbai%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1733413089540!5m2!1sen!2sin"
              width="600"
              height="450"
              style="border: 0"
              allowfullscreen=""
              loading="lazy"
              referrerpolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>
      </div>
      <!--Pagination-->
      <div class="d-flex justify-content-center">
        <nav aria-label="Page navigation">
          <ul class="pagination">
            <li class="page-item disabled">
              <a class="page-link" href="#" aria-label="Previous">
                <span aria-hidden="true">&laquo;</span>
              </a>
            </li>
            <li class="page-item" aria-current="page">
              <a class="page-link" href="Home.php">1</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="show.php">2</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="About.php">3</a>
            </li>
            <li class="page-item active">
              <a class="page-link" href="Contact.php">4</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="Ty.php">5</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="Comming.php">6</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="reg.php">7</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="#" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </main>
    <footer class="text-center bg-dark text-white py-3">
      <!-- place footer here -->
      <h4>&copy; All Rights Are Reserved</h4>
    </footer>
    <!-- Bootstrap JavaScript Libraries -->
    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
      integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
      crossorigin="anonymous"
    ></script>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
      integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
