<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS v5.2.1 -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
      crossorigin="anonymous"
    />
  </head>

  <body style="background-color: rgb(213, 205, 205)">
    <header>
      <!-- place navbar here -->
    </header>
    <main>
      <h2 
        class="text-center mt-5">ADD TO BAG
      </h2>
      <div class="container col-6 mt-4">
        <form action="" method="POST">
          <div class="form-floating mb-3">
            <input
              type="text"
              class="form-control"
              name="product"
              id="formId1"
              placeholder=""
              required
            />
            <label for="formId1">Product</label>
          </div>
          <div class="form-floating mb-3">
            <input
              type="text"
              class="form-control"
              name="title"
              id="formId1"
              placeholder=""
              required
            />
            <label for="formId1">Title</label>
          </div>
          <div class="form-floating mb-3">
            <input
              type="text"
              class="form-control"
              name="qty"
              id="formId1"
              placeholder=""
              required
            />
            <label for="formId1">Qty</label>
          </div>
          
          <div class="form-floating mb-3">
            <input
              type="number"
              class="form-control"
              name="amount"
              id="formId1"
              placeholder=""
              required
            />
            <label for="formId1">Amount</label>
          </div>

          <div class="text-center">
            <button type="submit" class="btn btn-primary">Add Product</button><br>
            
          </div>
        </form><br>
        <a style="margin-left: 150px"; href="export.php"><button type="submit" class="btn btn-primary">Download Excel_file</button></a>
        <a style="margin-left: 110px"; href="myglam-pdf.php"><button type="submit" name="submit" class="btn btn-primary">Download PDF_File</button></a> 
        <br>
        <a  class="" href="show.php">Show</a>
        <a  class="" href="Home.php">Home</a>
        
      </div>
    </main>
    <footer>
      <!-- place footer here -->
    </footer>
    <!-- Bootstrap JavaScript Libraries -->
    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
      integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
      crossorigin="anonymous"
    ></script>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
      integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
      crossorigin="anonymous"
    ></script>
  </body>
</html>

<?php

  include 'DB.php';

  if($_SERVER['REQUEST_METHOD'] == "POST"){
    $product = $_POST["product"];
    $title = $_POST["title"];
    $qty = $_POST["qty"];
    $amount = $_POST["amount"];

    $sql = $conn->prepare("insert into glammin(Product,Title,Qty,Amount) values(?,?,?,?)");
    $sql->bind_param("ssid", $product, $title, $qty, $amount);
    
    if($sql->execute()){
      echo '<script>alert("Product added succefully")</script>';
    }
    else{
      echo "Please enter data properly.";
    }
  }
?>
